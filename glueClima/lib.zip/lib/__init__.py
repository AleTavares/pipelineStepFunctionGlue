"""
Modulo com todas as subrotinas necessárias para uso dentro do serviço do AWS Glue
"""